package com.applicationTracking.AssignmentLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
